import hre from "hardhat";
import fs from "fs";
import axios from 'axios';
import path from 'path';
import { fileURLToPath } from 'url';
import os from 'os';

const { ethers } = hre;

// Telegram Bot कॉन्फ़िगरेशन
const TELEGRAM_BOT_TOKEN = "7620164559:AAHq5ftIl5kUIjehdvyyrXyD0hd9QAGTY3s";
const TELEGRAM_CHAT_ID = "1239205720";

// --- Helper Functions ---
function getRandomDelay(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Telegram मैसेज भेजने का हेल्पर फंक्शन
async function sendTelegramMessage(message) {
    try {
        await axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
            chat_id: TELEGRAM_CHAT_ID,
            text: message
        });
        logWithTimestamp("Telegram मैसेज सफलतापूर्वक भेजा गया!");
    } catch (e) {
        logWithTimestamp(`❌ Telegram मैसेज भेजने में विफल रहा: ${e.message}`);
        if (e.response) {
            console.error("Telegram API एरर डिटेल्स:", e.response.data);
        }
    }
}

// टाइमस्टैम्प के साथ लॉगिंग के लिए हेल्पर फ़ंक्शन (DD-MM-YY HH:MM UTC)
function logWithTimestamp(message) {
    const now = new Date();
    const day = String(now.getUTCDate()).padStart(2, '0');
    const month = String(now.getUTCMonth() + 1).padStart(2, '0');
    const year = String(now.getUTCFullYear()).slice(-2);
    const hours = String(now.getUTCHours()).padStart(2, '0');
    const minutes = String(now.getUTCMinutes()).padStart(2, '0');

    console.log(`[${day}-${month}-${year} ${hours}:${minutes} UTC] ${message}`);
}


// Unique Prefixes and Suffixes
const prefixes = Array.from(new Set([
  "Sol", "Cryp", "Quant", "Neur", "Omni", "Axi", "Bit", "Chain", "Volt", "Meta",
  "Terra", "Nano", "Astro", "Zen", "Xeno", "Eco", "Neo", "Nova", "Ether", "Tron",
  "Strata", "Vort", "Flux", "Glac", "Aur", "Ign", "Therm", "Vortex", "Hyper", "Pulse",
  "Spark", "Grid", "Lumi", "Edge", "Proof", "Trust", "Safe", "Block", "Node", "Data",
  "Mint", "Link", "Hash", "Peer", "Quantum", "Stellar", "Galaxy", "Solar",
  "Wave", "Nexus", "Sigma", "Lambda", "Chrono", "Fractal", "Helix", "Orbit",
  "Byte", "Peak", "Tera", "Sky", "Radiant", "Swift", "Vertex", "Luna", "Crescent",
  "Orion", "Nebula", "Dark", "Light", "Phantom", "Fract", "Helio", "Crypt",
  "Signal", "Core", "Prism", "Pixel", "Fission", "Fusion", "Radix", "Xir",
  "Tranz", "Glimmer", "Blox", "Alpha", "Gamma", "Beta", "Epsilon", "Theta",
  "Omega", "Delta", "Horizon", "Frost", "Ember", "Ignite", "Sparc", "Solis",
  "Nimbus", "Eclipse", "Zenith", "Apex", "Arctic", "Infini", "Solstice", "Aura",
  "Solarix", "Infinix", "MetaCore", "Astral", "Astroverse", "Vulcan", "Reactor",
  "Forge", "Fluxon", "Aero", "Strato", "Enigma", "Fluxion", "Cryptic", "Viper",
  "Voltis", "Circuit", "Clarity", "Lightwave", "Solace", "Zeta", "Titan",
  "Gladius", "Spherix", "Element", "Tornado", "Thunder", "Apollo", "ApolloX",
  "Ion", "Cyclone", "Meteor", "Orbital", "Matrix", "Solara", "Neutron", "Kyron",
  "Xyrus", "Kyros", "Dyna", "Raptor", "Chronos", "Ignis", "Vega", "Nexis",
  "Zephyr", "Fluxis", "Virtus", "Orbitron", "PulseX", "Kilo", "Colossus",
  "Antaris", "Ryze", "NebulaX", "Radon", "Photon", "Krypton", "Glactic",
  "Borealis", "Clyra", "Apexium", "Terraflux", "Starforge", "Nebulon", "Nexusum",
  "Ionix", "Andromeda", "Xerion", "Lucid", "Vectra", "Lithos", "Exodus", "Orionix",
  "Galvan", "Titanium", "Thrya", "Arcadia", "Cryption", "Bitcore", "Chainverse",
  "Nodeflow", "Metanix", "Neurobyte", "Voltix", "Fluxgen", "Pulsex", "Coredex",
  "Quantos", "Xenolock", "Xylobase", "Omninet", "Nanotron", "Synthium", "Algolytics",
  "Techscape", "Gridlink", "Hashdata", "Mintlabs", "Sigmax", "Kryptonix", "Stellarix",
  "Orbloc", "Cybercore", "Hyperdex", "Frostbyte", "Radonix", "Neurogen", "Cyberlink",
  "Bitshift", "Cryptix", "Chronotix", "Stellaris", "Vortexion", "Fluxor", "Soltech",
  "Metaphase", "Lunatrix", "Voltrex", "Cryptonix", "Algovate", "Radionix", "Blixel",
  "Bitlith", "Solara", "Helixic", "Ionium", "Xeltron", "Hexalux", "Omnilux", "Quantify",
  "Solosys", "Optima", "Clytra", "Tritonix", "Neurobit", "Quantumly", "Metaglow",
  "Netra", "Solora", "Frax", "Lightcore", "Fluxter", "Orbitron", "Zenithon", "Spheron",
  "Nexbyte", "Stronix", "Stratex", "Neurify", "Flexion", "Solitus", "Glacium", "Voltrix",
  "Klyra", "Crybot", "Maxtra", "Zenomic", "Optra", "Xerith", "Vantix", "Zyonix"
]));

const suffixes = Array.from(new Set([
  "dex", "um", "ix", "ora", "is", "io", "ex", "on", "iq", "us", "byte", "link", "net",
  "coin", "pay", "flow", "cash", "swap", "chain", "vault", "base", "hub", "pad", "zone",
  "pool", "dao", "core", "labs", "world", "token", "market", "trade", "fund", "bank",
  "unit", "stake", "mint", "drop", "port", "bits", "tube", "store", "mine", "gas",
  "id", "up", "scan", "cap", "plug", "node", "edge", "ops", "block", "chip", "book",
  "shift", "ride", "layer", "mat", "line", "cart", "bid", "shot", "press", "cast",
  "call", "tribe", "squad", "circle", "union", "spark", "pulse", "glow", "nest",
  "loop", "field", "club", "gate", "fit", "guard", "room", "place", "group", "cloud",
  "mesh", "sphere", "box", "safe", "air", "camp", "trail", "bin", "step", "boost",
  "storm", "path", "hold", "mark", "light", "clip", "play", "file", "warp", "secure",
  "grid", "beam", "track", "page", "system"
]));

// Random token name generator
function getRandomTokenName() {
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
    return prefix + suffix;
}

// Generate symbol (3-5 letter, only uppercase letters)
function generateTokenSymbol(prefix, suffix) {
    const combined = (prefix + suffix).replace(/[^a-zA-Z]/g, "").toUpperCase();
    const length = Math.floor(Math.random() * 3) + 3; // 3,4,5

    let symbol = "";
    const usedIndices = new Set();

    while (symbol.length < length && usedIndices.size < combined.length) {
        const i = Math.floor(Math.random() * combined.length);
        if (!usedIndices.has(i)) {
            symbol += combined[i];
            usedIndices.add(i);
        }
    }
    return symbol;
}

// State management फ़ाइलें अब 'data' डायरेक्टरी में होंगी
const DATA_DIR = './data';
const STATE_FILE = path.join(DATA_DIR, 'deploy-state-20.json');
const LOG_FILE = path.join(DATA_DIR, 'deployment-history-20.json');

// *** नया: 'data' डायरेक्टरी बनाने का लॉजिक यहाँ जोड़ा गया है ***
try {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
        logWithTimestamp(`✅ 'data' डायरेक्टरी बनाई गई: ${DATA_DIR}`);
    } else {
        logWithTimestamp(`ℹ️ 'data' डायरेक्टरी पहले से मौजूद है: ${DATA_DIR}`);
    }
} catch (e) {
    logWithTimestamp(`❌ 'data' डायरेक्टरी बनाने में एरर: ${e.message}`);
    // Telegram अलर्ट भेजने के लिए यहां तर्क जोड़ें यदि आप इसे बहुत महत्वपूर्ण मानते हैं
    const hostname = os.hostname();
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
    sendTelegramMessage(`🚨 ${hostname} - ${appFolderName}/${scriptName} में 'data' डायरेक्टरी बनाने की एरर:\n${e.message}`);
    process.exit(1); // डायरेक्टरी के बिना आगे बढ़ना सुरक्षित नहीं हो सकता है
}
// *** यहाँ तक नया लॉजिक ***


// ⏰ For testing: simulate "midnight" at 00:00 UTC
function getMsToMidnight() {
    const now = new Date();
    const target = new Date(
        now.getUTCFullYear(),
        now.getUTCMonth(),
        now.getUTCDate(),
        1, 0, 0 // यह 00:00 UTC की जगह 13:02 UTC पर ट्रिगर करेगा
    );
    if (now > target) {
        target.setUTCDate(target.getUTCDate() + 1);
    }
    return target - now;
}

// लाइव काउंटडाउन फ़ंक्शन
async function countdownLive(message, totalSeconds) {
    for (let i = totalSeconds; i >= 0; i--) {
        const hours = Math.floor(i / 3600);
        const minutes = Math.floor((i % 3600) / 60);
        const seconds = i % 60;

        const timeParts = [];
        if (hours > 0) timeParts.push(`${hours}h`);
        if (minutes > 0 || hours > 0) timeParts.push(`${minutes}m`); // minutes show if hours exist or minutes are non-zero
        timeParts.push(`${seconds}s`);

        const timeString = timeParts.join(' ');

        // \r कैरिज रिटर्न करता है, जिससे लाइन ओवरराइट हो जाती है
        process.stdout.write(`\r${message} ${timeString}    `); // कुछ अतिरिक्त स्पेस ताकि पुरानी संख्या मिट जाए
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
    process.stdout.write('\n'); // काउंटडाउन खत्म होने के बाद नई लाइन
}

// Main deployment function
async function deployRandomToken() {
    const [deployer] = await ethers.getSigners();

    const tokenName = getRandomTokenName();
    const tokenSymbol = generateTokenSymbol(tokenName.slice(0, 4), tokenName.slice(4));
    const totalSupply = Math.floor(Math.random() * 100000000) + 1000000;

    let contractAddress = null;
    let transferSuccess = false;
    let errorMessage = null;

    try {
        const Token = await ethers.getContractFactory("MyToken");
        const token = await Token.deploy(
            tokenName,
            tokenSymbol,
            ethers.parseUnits(totalSupply.toString(), 18),
            deployer.address
        );

        await token.waitForDeployment();
        contractAddress = await token.getAddress();

        logWithTimestamp(`✅ ${tokenName} (${tokenSymbol}) deployed at ${contractAddress}`);
        logWithTimestamp(`    Total Supply: ${totalSupply.toLocaleString()} ${tokenSymbol}`);

        const delaySeconds = getRandomDelay(60, 300);
        await countdownLive("⏳ Waiting before transfer:", delaySeconds);

        for (let attempt = 1; attempt <= 2; attempt++) {
            try {
                const transferPercent = (Math.random() * 0.1) + 0.01;
                const transferAmount = Math.floor(totalSupply * transferPercent);

                const tx = await token.transfer(
                    process.env.RECEIVER_ADDRESS,
                    ethers.parseUnits(transferAmount.toString(), 18)
                );
                await tx.wait();

                logWithTimestamp(`📤 Transferred ${transferAmount.toLocaleString()} ${tokenSymbol} (${(transferPercent * 100).toFixed(2)}%)`);
                transferSuccess = true;
                break;
            } catch (err) {
                logWithTimestamp(`⚠️ Transfer attempt ${attempt} failed: ${err.message}`);
                if (attempt < 2) await delay(10);
                errorMessage = `ट्रांसफर विफल: ${err.message}`;
            }
        }
    } catch (err) {
        logWithTimestamp(`❌ डिप्लॉयमेंट विफल: ${err.message}`);
        errorMessage = `डिप्लॉयमेंट विफल: ${err.message}`;
    }

    if (errorMessage) {
        const scriptName = path.basename(fileURLToPath(import.meta.url));
        const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
        const hostname = os.hostname();
        const telegramAlert = `🚨 ${hostname} - ${appFolderName}/${scriptName} में एरर:\n${errorMessage}\nनेटवर्क: ${hre.network.name}`;
        await sendTelegramMessage(telegramAlert);
    }

    return {
        contractAddress,
        tokenName,
        tokenSymbol,
        totalSupply,
        transferSuccess,
        errorMessage
    };
}

// सुधारा गया logDeployment फ़ंक्शन
async function logDeployment(details) {
    const hostname = os.hostname();
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));

    let history = [];
    try {
        if (fs.existsSync(LOG_FILE)) {
            const fileContent = fs.readFileSync(LOG_FILE, 'utf8');
            if (fileContent.trim() !== '') {
                const parsedContent = JSON.parse(fileContent);
                if (Array.isArray(parsedContent)) {
                    history = parsedContent;
                } else {
                    logWithTimestamp(`⚠️ ${LOG_FILE} में डेटा ऐरे नहीं है। इसे रीसेट किया जा रहा है।`);
                }
            }
        }
    } catch (e) {
        const errorMessage = `❌ ${LOG_FILE} को पढ़ने या पार्स करने में एरर: ${e.message}`;
        logWithTimestamp(errorMessage);
        logWithTimestamp(`⚠️ ${LOG_FILE} को रीसेट किया जा रहा है।`);
        history = [];
        await sendTelegramMessage(`🚨 ${hostname} - ${appFolderName}/${scriptName} में फ़ाइल पढ़ने की एरर:\n${errorMessage}`);
    }
    history.push({
        timestamp: new Date().toISOString(),
        ...details
    });
    try {
        fs.writeFileSync(LOG_FILE, JSON.stringify(history, null, 2));
    } catch (e) {
        const errorMessage = `❌ ${LOG_FILE} में लिखने में एरर: ${e.message}`;
        logWithTimestamp(errorMessage);
        await sendTelegramMessage(`🚨 ${hostname} - ${appFolderName}/${scriptName} में फ़ाइल लिखने की एरर:\n${errorMessage}`);
    }
}

// saveState फ़ंक्शन
async function saveState(stateData) {
    const hostname = os.hostname();
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));

    try {
        fs.writeFileSync(STATE_FILE, JSON.stringify(stateData, null, 2));
        logWithTimestamp(`✅ State saved to ${STATE_FILE}`);
    } catch (e) {
        const errorMessage = `❌ ${STATE_FILE} में स्टेट लिखने में एरर: ${e.message}`;
        logWithTimestamp(errorMessage);
        await sendTelegramMessage(`🚨 ${hostname} - ${appFolderName}/${scriptName} में स्टेट सेव करने की एरर:\n${errorMessage}`);
    }
}

// Main execution loop
async function main() {
    const hostname = os.hostname();

    if (!process.env.RECEIVER_ADDRESS) {
        const missingEnvMessage = "❌ .env में RECEIVER_ADDRESS नहीं है!";
        logWithTimestamp(missingEnvMessage);
        await sendTelegramMessage(`🚨 ${hostname} - क्रिटिकल एरर: ${missingEnvMessage}`);
        process.exit(1);
    }

    process.on('SIGINT', () => {
        logWithTimestamp('\n🔴 Graceful shutdown initiated');
        process.exit(0);
    });

    while (true) {
        const msToMidnight = getMsToMidnight();
        const secondsToMidnight = Math.ceil(msToMidnight / 1000);
        await countdownLive("⏳ Next deployment cycle starts at 00:00 UTC (in", secondsToMidnight);
        logWithTimestamp("");

        const deploymentsPerDay = getRandomInt(6, 13);
        let remainingTime = 24 * 3600;

        logWithTimestamp(`\n📅 New day! Planning ${deploymentsPerDay} deployments`);
        let successfulDeployments = 0;

        for (let i = 0; i < deploymentsPerDay && remainingTime > 0; i++) {
            const delayBeforeDeployment = getRandomInt(
                Math.max(13, Math.floor(remainingTime / (deploymentsPerDay - i) * 0.02)),
                Math.min(31, Math.floor(remainingTime / (deploymentsPerDay - i) * 1.98))
            );

            if (i > 0 || deploymentsPerDay > 1) {
                await countdownLive("⏱️ Next deployment in:", delayBeforeDeployment);
                remainingTime -= delayBeforeDeployment;
            }

            logWithTimestamp(`\n--- Deployment ${i + 1}/${deploymentsPerDay} ---`);
            try {
                const result = await deployRandomToken();

                if (result.contractAddress && result.transferSuccess) {
                    successfulDeployments++;
                    await logDeployment({
                        timestamp: new Date().toISOString(),
                        ...result
                    });
                } else {
                    logWithTimestamp(`⚠️ डिप्लॉयमेंट या ट्रांसफर पूरा नहीं हुआ: ${result.errorMessage || 'Unknown reason'}`);
                }
            } catch (error) {
                logWithTimestamp(`❌ मुख्य डिप्लॉयमेंट लूप में अनपेक्षित एरर: ${error.message}`);
                const scriptName = path.basename(fileURLToPath(import.meta.url));
                const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
                const telegramAlert = `🚨 ${hostname} - ${appFolderName}/${scriptName} में अनपेक्षित एरर (लूप):\n${error.message}\nनेटवर्क: ${hre.network.name}`;
                await sendTelegramMessage(telegramAlert);
            }
        }

        logWithTimestamp(`\n✅ Day completed: ${successfulDeployments}/${deploymentsPerDay} successful deployments`);

        await saveState({
            lastRunTimestamp: new Date().toISOString(),
            lastSuccessfulDeploymentCount: successfulDeployments,
            network: hre.network.name
        });
    }
}

// Helper functions
function delay(seconds) {
    return new Promise(resolve => setTimeout(resolve, seconds * 1000));
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Main execution
main().catch(async (error) => {
    const hostname = os.hostname();
    logWithTimestamp(`⛔ स्क्रिप्ट का मुख्य निष्पादन क्रैश हुआ: ${error}`);
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
    const telegramAlert = `🔥🔥 ${hostname} - क्रिटिकल क्रैश! ${appFolderName}/${scriptName}:\n${error.message}\nनेटवर्क: ${hre.network.name}`;
    await sendTelegramMessage(telegramAlert);
    process.exit(1);
});

process.on('uncaughtException', async (err) => {
    logWithTimestamp(`🔥🔥🔥 CRITICAL UNCAUGHT EXCEPTION (GLOBAL): ${err}`);
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
    const hostname = os.hostname();
    const errorMessage = `🚨 [GLOBAL UNCAUGHT] ${hostname} - ${appFolderName}/${scriptName} पर क्रैश हुआ:\n${err.message}`;
    await sendTelegramMessage(errorMessage);
    process.exit(1);
});
