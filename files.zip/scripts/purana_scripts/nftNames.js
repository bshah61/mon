// scripts/nftNames.js

export const prefixes = [
  "Meta", "Crypto", "Neo", "Nova", "Pixel", "Astral", "Void", "Myth", "Solar", "Luna",
  "Blockchain", "Token", "Mint", "Chain", "NFT", "Aether", "Crypt", "Ether", "Genesis", "NFTverse",
  "Web3", "Hash", "Ledger", "Art", "Viral", "Virtual", "NFTWorld", "Tokenized", "Digital", "Holo",
  "Eclipse", "Vortex", "Gallery", "Cyber", "Hyper", "Astra", "Arti", "Artis", "Minted", "MetaChain",
  "CryptoMint", "PixelMint", "Future", "Decentral", "Block", "Vault", "Insta", "Matrix", "ArtHub", "Tokenize",
  "ChainVerse", "CryptoVerse", "Bit", "Avatar", "Rare", "Dream", "ChainMint", "BlockMint", "Digi", "Sky",
  "MetaMint", "MetaDrop", "CoinMint", "Hype", "Uniq", "Nifty", "MetaCore", "Artverse", "Soul", "Byte",
  "Bitverse", "ArtChain", "Mintverse", "BitDrop", "TokenCore", "CyberMint", "Star", "Beam", "MetaArt",
  "DreamChain", "Cloud", "Glitch", "Wired", "PixelDrop", "TokenSpark", "CryptoForge", "MetaPixel", "CyberDrop",
  "Neon", "ArtDrop", "MetaToken", "Nexus", "TokenZone", "MintSpark", "MetaZone", "MetaLabs", "BlockForge", "NovaMint",
  "CryptoEdge", "TokenNet", "DigiMint", "RareMint", "DropNet", "BitForge", "TokenMatrix", "Xeno", "Yotta", "ChainSpark",
  "MetaNexus", "MetaNet", "MetaBit", "TokenSphere", "HoloMint", "MetaChainz", "Zetta", "MintMatrix", "Quantum", "Axi",
  "Omni", "ArtEdge", "MintFlow", "ChainLab", "NFTForge", "ChainEdge", "MetaGalaxy", "TokenLab", "CyberLab", "MintZone",
  "ChainCore", "TokenHive", "NFTPad", "ChainPad", "MetaHive", "CryptoHive", "MetaNode", "TokenNode", "CryptoPulse", "NFTBeat",
  "ChainDrop", "MetaWorld", "TokenDrop", "MetaStream", "Pixelverse", "MintPortal", "Cryptex", "MintPad", "NFTLabs", "HypeMint",
  "MetaByte", "ChainBytes", "CyberVerse", "NFTChain", "CryptoPulse", "MetaCube", "ArtCube", "TokenPlanet", "ChainX", "CyberX",
  "MetaX", "PixelX", "BitX", "DigiX", "XMint", "MetaFi", "NFTFi", "ChainFi", "ArtFi", "TokenFi",
  "MintFi", "MetaLoop", "ChainLoop", "MetaLink", "ChainLink", "BlockLink", "TokenLoop", "PixelLab", "CyberCore", "ChainMatrix",
  "VaultMint", "NeoMint", "SolarMint", "LunaMint", "VoidMint", "MythMint", "EtherMint", "CryptoZone", "TokenCube", "MetaForge",
  "NFTX", "ChainCloud", "TokenCloud", "BlockCloud", "PixelCloud", "Artify", "Mintify", "Tokenify", "Chainify", "Cyberify",
  "NFTify", "Metaify", "Bitify", "MintBot", "NFTBot", "MetaBot", "TokenBot", "CyberBot", "ChainBot", "BlockBot",
  "MintEngine", "TokenEngine", "MetaEngine", "ChainEngine", "PixelEngine", "NFTEngine", "ForgeMint", "ForgeChain", "ForgeToken", "MetaFrame",
  "CyberFrame", "ChainFrame", "PixelFrame", "TokenFrame", "ArtFrame", "MetaMeta", "CyberMeta", "TokenBase", "ChainBase", "MintBase",
  "MetaBase", "CyberBase", "ArtBase", "PixelBase", "TokenPath", "MintPath", "ChainPath", "MetaPath", "VaultX", "VaultZone",
  "VaultDrop", "ChainMind", "TokenMind", "MetaMind", "MintMind", "PixelMind", "BlockMind", "NFTMind", "ChainFlow", "TokenFlow",
  "MetaFlow", "CyberFlow", "MintFlow", "ArtFlow", "PixelFlow", "TokenDeck", "ChainDeck", "MetaDeck", "NFTDeck", "CyberDeck",
  "BlockVerse", "TokenVerse", "MintVerse", "CyberVerse", "ArtVerse", "ChainSpace", "TokenSpace", "MetaSpace", "NFTSpace", "CyberSpace"
];

export const suffixes = [
  "NFT", "Art", "Zone", "Chain", "World", "Verse", "Studio", "Lab", "Vault", "Drop",
  "Gallery", "Mint", "Collectible", "Token", "Hub", "Network", "Worlds", "Platform", "Series",
  "Space", "Exchange", "Genesis", "Craft", "ArtChain", "Vault", "Galaxy", "Matrix", "Fusion",
  "Collection", "ArtVault", "Cyber", "Lens", "Pulse", "Edge", "Core", "Universe", "Craft",
  "Artifact", "Tokenized", "Bit", "Realm", "Lands", "Block", "Arena", "Meta", "Folio", "Realm",
  "Metaverse", "Web3", "Genesis", "Legacy", "Interactive", "Prism", "Element", "Matrix", "ChainX"
];
