// scripts/nftAttributes.js

export const elements = ["Fire", "Water", "Earth", "Air", "Light", "Darkness"];

const intros = ["Behold", "Discover", "Uncover", "Experience", "Summon", "Embrace", "Awaken", "Harness", "Unleash", "Explore",
    "Witness", "Observe", "Gaze upon", "Contemplate", "Decipher", "Unravel", "Seek", "Grasp",
    "Cherish", "Revere", "Admire", "Encounter", "Feel the presence of",
    "Presenting", "Here lies", "Revealing"];

const adjectives = ["legendary", "ancient", "mystical", "rare", "powerful", "enigmatic", "celestial", "ethereal", "mythical", "fabled",
    "valuable", "sacred", "cursed", "blessed", "forgotten", "revered", "primal",
    "arcane", "cosmic", "spectral", "haunted", "radiant", "luminescent", "vibrant", "dormant", "awakened", "potent", "immemorial",
    "crystalline", "metallic", "wooden", "stone-carved", "gossamer", "gleaming", "shimmering", "shadowy"];

const nouns = ["warrior", "artifact", "creature", "guardian", "spirit", "champion", "relic", "entity", "legend", "sentinel",
    "beast", "avatar", "golem", "automaton", "daemon", "phantom", "chimera", "herald", "sovereign", "oracle", "enigma",
    "tome", "amulet", "scepter", "crown", "orb", "scroll", "rune", "shard", "fragment", "echo", "vision", "dream", "essence", "talisman", "sigil", "cipher", "chronicle", "vestige"];

const actions = [
    // उत्पत्ति और सृजन (Origin & Creation)
    "born from the stars.",
    "forged in the ancient fires.",
    "fashioned by celestial artisans.",
    "shaped by cosmic dust.",
    "whispered into existence.",
    "conceived in the void.",
    "birthed by primordial energies.",
    "carved from the heart of a nebula.",
    "crystallized from ethereal light.",
    "grown in the depths of ancient earth.",
    "woven from the threads of destiny.",
    "conjured by forgotten rituals.",
    "emerging from the cosmic egg.",
    "manifested by pure will.",
    "spun from moonbeams and stardust.",
    "hewn from slumbering mountains.",
    "ignited by a divine spark.",
    "descended from celestial planes.",
    "formed in the crucible of creation.",
    "reborn from the ashes of epochs.",

    // स्थान और स्थिति (Location & State)
    "lost in the sands of time.",
    "hidden deep in the forest.",
    "slumbering beneath the earth.",
    "floating in the void.",
    "perched atop forgotten peaks.",
    "residing in the astral plane.",
    "sealed within a timeless vault.",
    "lurking in the shadows of reality.",
    "bound to a forgotten temple.",
    "imprisoned in a cursed dimension.",
    "sleeping in a crystal cavern.",
    "enshrined in a sacred grove.",
    "anchored to the core of a dying star.",
    "drifting through fragmented memories.",
    "held captive by ancient curses.",
    "waiting in the silent halls of oblivion.",
    "buried beneath the roots of the world.",
    "concealed within the heart of a storm.",
    "frozen in the embrace of eternity.",
    "resting within a shimmering illusion.",

    // रहस्य और अप्रकट (Mystery & Unrevealed)
    "shrouded in mystery.",
    "waiting to be discovered.",
    "echoing through the ages.",
    "enchanted by forgotten magic.",
    "guarded by mystical forces.",
    "bearing a terrible secret.",
    "its true nature remains hidden.",
    "its purpose long forgotten.",
    "unseen by mortal eyes.",
    "whispering untold tales.",
    "holding secrets of the cosmos.",
    "veiled by powerful enchantments.",
    "a riddle whispered by the wind.",
    "its origins lost to legend.",
    "known only to a select few.",
    "a phantom of a bygone era.",
    "hidden from the grasp of time.",
    "an enigma wrapped in starlight.",
    "a forgotten prophecy fulfilled.",
    "the subject of ancient prophecies.",

    // उद्देश्य और भाग्य (Purpose & Destiny)
    "destined for greatness.",
    "holding untold power.",
    "a beacon of hope.",
    "a harbinger of change.",
    "chosen by fate.",
    "bound to a grand purpose.",
    "foretold in ancient texts.",
    "a catalyst for transformation.",
    "the key to a forgotten empire.",
    "an instrument of balance.",
    "designed for an ultimate quest.",
    "imbued with celestial power.",
    "charged with cosmic energy.",
    "fuelled by raw magic.",
    "blessed with divine foresight.",
    "cursed with eternal vigilance.",
    "a promise whispered across dimensions.",
    "wielding the essence of creation.",
    "forged for a singular destiny.",
    "empowered by ancient blessings.",

    // प्रभाव और प्रभाव (Effect & Impact)
    "shaping the very fabric of reality.",
    "influencing the flow of time.",
    "altering the course of civilizations.",
    "sending ripples through the multiverse.",
    "a force beyond mortal comprehension.",
    "drawing power from cosmic alignments.",
    "a nexus of elemental energies.",
    "resonating with the heartbeat of the universe.",
    "capable of unimaginable feats.",
    "a marvel of otherworldly design.",
    "unleashing cataclysmic might.",
    "a testament to boundless potential.",
    "a conduit for pure essence.",
    "radiating a calming aura.",
    "emitting a chilling presence.",
    "drawing souls into its orbit.",
    "reflecting the chaos of existence.",
    "a whisper in the cosmic wind.",
    "a mirror to the soul.",
    "a glimpse into forbidden knowledge.",

    // सुरक्षा और संरक्षण (Guardianship & Preservation)
    "guarded by ancient guardians.",
    "protected by impenetrable wards.",
    "safeguarded by celestial beings.",
    "preserved for a future awakening.",
    "a bulwark against encroaching darkness.",
    "a sanctuary of forgotten knowledge.",
    "shielded from the greedy and the unworthy.",
    "a fortress of unimaginable power.",
    "watched over by silent sentinels.",
    "its sanctity fiercely defended.",
    "a bastion against chaos.",
    "preserved through countless ages.",
    "a silent observer of history.",
    "custodian of cosmic secrets.",
    "veiled in protective enchantments.",
    "secured by unbreakable oaths.",
    "a sacred trust passed down through time.",
    "hidden from those who seek to exploit it.",
    "a silent vigil kept since dawn of time.",
    "its existence a closely guarded secret.",

    // विनाश और खतरा (Destruction & Threat)
    "a harbinger of ruin.",
    "capable of unspeakable destruction.",
    "tainted by a lingering darkness.",
    "a curse upon all who touch it.",
    "wielding chaotic energies.",
    "a relic of a bygone apocalypse.",
    "its power threatens to unravel reality.",
    "a shadow of impending doom.",
    "feeding on despair and fear.",
    "a conduit for forgotten evils.",
    "its touch brings forth oblivion.",
    "a grim reminder of shattered worlds.",
    "born from a tear in the fabric of space.",
    "a fragment of pure desolation.",
    "corrupted by forbidden knowledge.",
    "a nightmare given form.",
    "its presence warps the very air.",
    "a symbol of utter annihilation.",
    "a force of inescapable entropy.",
    "feared by gods and mortals alike.",

    // जीवन और चेतना (Life & Consciousness)
    "pulsating with ancient life.",
    "possessing a nascent consciousness.",
    "breathing with silent wisdom.",
    "a vessel for an unbound spirit.",
    "awakening to a new age.",
    "dreaming of untold futures.",
    "observing the ebb and flow of existence.",
    "a mind beyond human understanding.",
    "a soul yearning for liberation.",
    "its spirit intertwined with the cosmos.",
    "a living testament to creation.",
    "conscious beyond mortal grasp.",
    "an echo of a primordial mind.",
    "a silent witness to all things.",
    "its life force sustains ancient lands.",
    "a spark of sentience in the abyss.",
    "breathing untold tales into reality.",
    "a living enigma of the ages.",
    "infused with ancestral spirits.",
    "its sentience a bridge between worlds.",

    // परिवर्तन और विकास (Change & Evolution)
    "evolving with every passing age.",
    "shifting forms across dimensions.",
    "a conduit for cosmic change.",
    "transforming the very essence of its surroundings.",
    "adapting to the whims of the multiverse.",
    "a testament to eternal flux.",
    "reflecting the changing tides of existence.",
    "constantly seeking new forms.",
    "a journey without end.",
    "an endless cycle of rebirth.",
    "a canvas of infinite possibilities.",
    "molding reality to its own will.",
    "a dance between chaos and order.",
    "forever in a state of becoming.",
    "a living paradox of existence.",
    "influenced by unseen forces.",
    "reshaping fate with every beat.",
    "a beacon of endless potential.",
    "malleable to the touch of destiny.",
    "a tapestry of evolving narratives."
];

export function generateRandomDescription(tokenId) {
  const intro = intros[Math.floor(Math.random() * intros.length)];
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun = nouns[Math.floor(Math.random() * nouns.length)];
  const action = actions[Math.floor(Math.random() * actions.length)];
  return `${intro} a ${adj} ${noun} ${action}`;
}

export function getRandomRarity() {
  const rand = Math.random();
  if (rand > 0.95) return "Mythic";       // 5% chance
  if (rand > 0.85) return "Legendary";    // 10% chance
  if (rand > 0.65) return "Rare";         // 20% chance
  if (rand > 0.30) return "Uncommon";     // 35% chance
  return "Common";                       // 30% chance
}

export function getRandomGeneration() {
  return Math.floor(Math.random() * 5) + 1; // 1 to 5
}

export function getRandomElement() {
  return elements[Math.floor(Math.random() * elements.length)];
}

export function getRandomPowerLevel() {
  return Math.floor(Math.random() * 100) + 1; // 1 to 100
}

// ध्यान दें: generateRandomDescription यहाँ एक्सपोर्ट नहीं किया गया है
// क्योंकि यह केवल getRandomRarity, getRandomGeneration आदि को एक्सपोर्ट कर रहा था।
// अगर आपको generateRandomDescription को भी एक्सपोर्ट करना है,
// तो उसके आगे 'export' कीवर्ड जोड़ें: export function generateRandomDescription(...)
// और यह सुनिश्चित करें कि यह आपके 13.js में इंपोर्ट हो रहा है।
// आपके 13.js से मैंने इसे इंपोर्ट में नहीं देखा था।
