import hre from "hardhat";
import fs from "fs";
import axios from 'axios'; // <-- axios इम्पोर्ट करें
import path from 'path';   // <-- path इम्पोर्ट करें
import { fileURLToPath } from 'url'; // <-- fileURLToPath इम्पोर्ट करें

const { ethers } = hre;

// Telegram Bot कॉन्फ़िगरेशन
const TELEGRAM_BOT_TOKEN = "7620164559:AAHq5ftIl5kUIjehdvyyrXyD0hd9QAGTY3s"; // अपना बॉट टोकन यहाँ डालें
const TELEGRAM_CHAT_ID = "1239205720"; // अपनी चैट ID यहाँ डालें

// --- Helper Functions ---
function getRandomDelay(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Telegram मैसेज भेजने का हेल्पर फंक्शन
async function sendTelegramMessage(message) {
    try {
        await axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
            chat_id: TELEGRAM_CHAT_ID,
            text: message
        });
        console.log("Telegram मैसेज सफलतापूर्वक भेजा गया!");
    } catch (e) {
        console.error("❌ Telegram मैसेज भेजने में विफल रहा:", e.message);
        if (e.response) {
            console.error("Telegram API एरर डिटेल्स:", e.response.data);
        }
    }
}

// Unique Prefixes and Suffixes (आपकी पुरानी लिस्ट)
const prefixes = Array.from(new Set([
  "Sol", "Cryp", "Quant", "Neur", "Omni", "Axi", "Bit", "Chain", "Volt", "Meta",
  "Terra", "Nano", "Astro", "Zen", "Xeno", "Eco", "Neo", "Nova", "Ether", "Tron",
  "Strata", "Vort", "Flux", "Glac", "Aur", "Ign", "Therm", "Vortex", "Hyper", "Pulse",
  "Spark", "Grid", "Lumi", "Edge", "Proof", "Trust", "Safe", "Block", "Node", "Data",
  "Mint", "Link", "Hash", "Peer", "Quantum", "Stellar", "Galaxy", "Solar",
  "Wave", "Nexus", "Sigma", "Lambda", "Chrono", "Fractal", "Helix", "Orbit",
  "Byte", "Peak", "Tera", "Sky", "Radiant", "Swift", "Vertex", "Luna", "Crescent",
  "Orion", "Nebula", "Dark", "Light", "Phantom", "Fract", "Helio", "Crypt",
  "Signal", "Core", "Prism", "Pixel", "Fission", "Fusion", "Radix", "Xir",
  "Tranz", "Glimmer", "Blox", "Alpha", "Gamma", "Beta", "Epsilon", "Theta",
  "Omega", "Delta", "Horizon", "Frost", "Ember", "Ignite", "Sparc", "Solis",
  "Nimbus", "Eclipse", "Zenith", "Apex", "Arctic", "Infini", "Solstice", "Aura",
  "Solarix", "Infinix", "MetaCore", "Astral", "Astroverse", "Vulcan", "Reactor",
  "Forge", "Fluxon", "Aero", "Strato", "Enigma", "Fluxion", "Cryptic", "Viper",
  "Voltis", "Circuit", "Clarity", "Lightwave", "Solace", "Zeta", "Titan",
  "Gladius", "Spherix", "Element", "Tornado", "Thunder", "Apollo", "ApolloX",
  "Ion", "Cyclone", "Meteor", "Orbital", "Matrix", "Solara", "Neutron", "Kyron",
  "Xyrus", "Kyros", "Dyna", "Raptor", "Chronos", "Ignis", "Vega", "Nexis",
  "Zephyr", "Fluxis", "Virtus", "Orbitron", "PulseX", "Kilo", "Colossus",
  "Antaris", "Ryze", "NebulaX", "Radon", "Photon", "Krypton", "Glactic",
  "Borealis", "Clyra", "Apexium", "Terraflux", "Starforge", "Nebulon", "Nexusum",
  "Ionix", "Andromeda", "Xerion", "Lucid", "Vectra", "Lithos", "Exodus", "Orionix",
  "Galvan", "Titanium", "Thrya", "Arcadia", "Cryption", "Bitcore", "Chainverse",
  "Nodeflow", "Metanix", "Neurobyte", "Voltix", "Fluxgen", "Pulsex", "Coredex",
  "Quantos", "Xenolock", "Xylobase", "Omninet", "Nanotron", "Synthium", "Algolytics",
  "Techscape", "Gridlink", "Hashdata", "Mintlabs", "Sigmax", "Kryptonix", "Stellarix",
  "Orbloc", "Cybercore", "Hyperdex", "Frostbyte", "Radonix", "Neurogen", "Cyberlink",
  "Bitshift", "Cryptix", "Chronotix", "Stellaris", "Vortexion", "Fluxor", "Soltech",
  "Metaphase", "Lunatrix", "Voltrex", "Cryptonix", "Algovate", "Radionix", "Blixel",
  "Bitlith", "Solara", "Helixic", "Ionium", "Xeltron", "Hexalux", "Omnilux", "Quantify",
  "Solosys", "Optima", "Clytra", "Tritonix", "Neurobit", "Quantumly", "Metaglow",
  "Netra", "Solora", "Frax", "Lightcore", "Fluxter", "Orbitron", "Zenithon", "Spheron",
  "Nexbyte", "Stronix", "Stratex", "Neurify", "Flexion", "Solitus", "Glacium", "Voltrix",
  "Klyra", "Crybot", "Maxtra", "Zenomic", "Optra", "Xerith", "Vantix", "Zyonix"
]));

const suffixes = Array.from(new Set([
  "dex", "um", "ix", "ora", "is", "io", "ex", "on", "iq", "us", "byte", "link", "net",
  "coin", "pay", "flow", "cash", "swap", "chain", "vault", "base", "hub", "pad", "zone",
  "pool", "dao", "core", "labs", "world", "token", "market", "trade", "fund", "bank",
  "unit", "stake", "mint", "drop", "port", "bits", "tube", "store", "mine", "gas",
  "id", "up", "scan", "cap", "plug", "node", "edge", "ops", "block", "chip", "book",
  "shift", "ride", "layer", "mat", "line", "cart", "bid", "shot", "press", "cast",
  "call", "tribe", "squad", "circle", "union", "spark", "pulse", "glow", "nest",
  "loop", "field", "club", "gate", "fit", "guard", "room", "place", "group", "cloud",
  "mesh", "sphere", "box", "safe", "air", "camp", "trail", "bin", "step", "boost",
  "storm", "path", "hold", "mark", "light", "clip", "play", "file", "warp", "secure",
  "grid", "beam", "track", "page", "system"
]));

// Random token name generator
function getRandomTokenName() {
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
    return prefix + suffix;
}

// Generate symbol (3-5 letter, only uppercase letters)
function generateTokenSymbol(prefix, suffix) {
    const combined = (prefix + suffix).replace(/[^a-zA-Z]/g, "").toUpperCase();
    const length = Math.floor(Math.random() * 3) + 3; // 3,4,5

    let symbol = "";
    const usedIndices = new Set();

    while (symbol.length < length && usedIndices.size < combined.length) {
        const i = Math.floor(Math.random() * combined.length);
        if (!usedIndices.has(i)) {
            symbol += combined[i];
            usedIndices.add(i);
        }
    }
    return symbol;
}

// State management
const STATE_FILE = 'deploy-state.json';
const LOG_FILE = 'deployment-history.json';

// ⏰ For testing: simulate "midnight" at 00:00 UTC
function getMsToMidnight() {
    const now = new Date();
    const target = new Date(
        now.getUTCFullYear(),
        now.getUTCMonth(),
        now.getUTCDate(),
        0, 0, 0
    );
    if (now > target) {
        target.setUTCDate(target.getUTCDate() + 1);
    }
    return target - now;
}

// Main deployment function
async function deployRandomToken() {
    const [deployer] = await ethers.getSigners();

    const tokenName = getRandomTokenName();
    const tokenSymbol = generateTokenSymbol(tokenName.slice(0, 4), tokenName.slice(4));
    const totalSupply = Math.floor(Math.random() * 100000000) + 1000000;

    let contractAddress = null;
    let transferSuccess = false;
    let errorMessage = null;

    try {
        const Token = await ethers.getContractFactory("MyToken");
        const token = await Token.deploy(
            tokenName,
            tokenSymbol,
            ethers.parseUnits(totalSupply.toString(), 18),
            deployer.address
        );

        await token.waitForDeployment();
        contractAddress = await token.getAddress();

        console.log(`✅ ${tokenName} (${tokenSymbol}) deployed at ${contractAddress}`);
        console.log(`    Total Supply: ${totalSupply.toLocaleString()} ${tokenSymbol}`);

        const delaySeconds = getRandomDelay(60, 300);
        console.log(`⏳ Waiting ${delaySeconds} seconds before transfer...`);
        await delay(delaySeconds);

        for (let attempt = 1; attempt <= 2; attempt++) {
            try {
                const transferPercent = (Math.random() * 0.1) + 0.01;
                const transferAmount = Math.floor(totalSupply * transferPercent);

                const tx = await token.transfer(
                    process.env.RECEIVER_ADDRESS,
                    ethers.parseUnits(transferAmount.toString(), 18)
                );
                await tx.wait();

                console.log(`📤 Transferred ${transferAmount.toLocaleString()} ${tokenSymbol} (${(transferPercent * 100).toFixed(2)}%)`);
                transferSuccess = true;
                break; // ट्रांसफर सफल होने पर लूप से बाहर निकलें
            } catch (err) {
                console.warn(`⚠️ Transfer attempt ${attempt} failed:`, err.message);
                if (attempt < 2) await delay(10); // दूसरी कोशिश से पहले थोड़ा इंतजार करें
                errorMessage = `ट्रांसफर विफल: ${err.message}`; // अंतिम एरर मैसेज कैप्चर करें
            }
        }
    } catch (err) {
        console.error(`❌ डिप्लॉयमेंट विफल: ${err.message}`);
        errorMessage = `डिप्लॉयमेंट विफल: ${err.message}`; // अंतिम एरर मैसेज कैप्चर करें
    }

    // अगर कोई एरर मैसेज है, तो Telegram पर भेजें
    if (errorMessage) {
        const scriptName = path.basename(fileURLToPath(import.meta.url));
        const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
        const telegramAlert = `🚨 ${appFolderName}/${scriptName} में एरर:\n${errorMessage}\nनेटवर्क: ${hre.network.name}`;
        await sendTelegramMessage(telegramAlert);
    }

    return {
        contractAddress,
        tokenName,
        tokenSymbol,
        totalSupply,
        transferSuccess,
        errorMessage // एरर मैसेज को भी रिटर्न करें
    };
}

// Main execution loop
async function main() {
    // Validate environment
    if (!process.env.RECEIVER_ADDRESS) {
        const missingEnvMessage = "❌ .env में RECEIVER_ADDRESS नहीं है!";
        console.error(missingEnvMessage);
        await sendTelegramMessage(`🚨 क्रिटिकल एरर: ${missingEnvMessage}`); // Telegram पर भी भेजें
        process.exit(1);
    }

    process.on('SIGINT', () => {
        console.log('\n🔴 Graceful shutdown initiated');
        process.exit(0);
    });

    while (true) {
        // Wait until midnight UTC
        const msToMidnight = getMsToMidnight();
        console.log(`\n⏳ Next deployment cycle starts at 00:00 UTC (in ${Math.floor(msToMidnight / 3600000)} hours)`);
        await new Promise(resolve => setTimeout(resolve, msToMidnight));

        const deploymentsPerDay = getRandomInt(6, 13);
        let remainingTime = 24 * 3600; // Seconds in a day
        let successfulDeployments = 0;

        console.log(`\n📅 New day! Planning ${deploymentsPerDay} deployments`);

        for (let i = 0; i < deploymentsPerDay && remainingTime > 0; i++) {
            // Random delay before each deployment (including first)
            const delayBeforeDeployment = getRandomInt(
                Math.max(13, Math.floor(remainingTime / (deploymentsPerDay - i) * 0.02)), // At least 1 min
                Math.min(31, Math.floor(remainingTime / (deploymentsPerDay - i) * 1.98)) // At most 1 hour
            );

            if (i > 0 || deploymentsPerDay > 1) {
                console.log(`\n⏱️ Waiting ${Math.floor(delayBeforeDeployment / 60)} minutes before next deployment...`);
                await delay(delayBeforeDeployment);
                remainingTime -= delayBeforeDeployment;
            }

            try {
                console.log(`\n--- Deployment ${i + 1}/${deploymentsPerDay} ---`);
                const result = await deployRandomToken();

                if (result.contractAddress && result.transferSuccess) {
                    successfulDeployments++;
                    // Log successful deployment
                    fs.appendFileSync(LOG_FILE, JSON.stringify({
                        timestamp: new Date().toISOString(),
                        ...result
                    }, null, 2) + '\n');
                } else {
                    console.error(`⚠️ डिप्लॉयमेंट या ट्रांसफर पूरा नहीं हुआ: ${result.errorMessage || 'Unknown reason'}`);
                    // deployRandomToken() के अंदर पहले ही Telegram मैसेज भेजा जा चुका होगा
                }
            } catch (error) {
                // यह कैच ब्लॉक उन एरर के लिए है जो deployRandomToken() के बाहर आती हैं
                // या deployRandomToken() में हैंडल नहीं होती हैं (जो अब कम संभावना है)
                console.error(`❌ मुख्य डिप्लॉयमेंट लूप में अनपेक्षित एरर: ${error.message}`);
                const scriptName = path.basename(fileURLToPath(import.meta.url));
                const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
                const telegramAlert = `🚨 ${appFolderName}/${scriptName} में अनपेक्षित एरर (लूप):\n${error.message}\nनेटवर्क: ${hre.network.name}`;
                await sendTelegramMessage(telegramAlert);
            }
        }

        console.log(`\n✅ Day completed: ${successfulDeployments}/${deploymentsPerDay} successful deployments`);
    }
}

// Helper functions (नीचे से ऊपर ले जाए गए ताकि सभी फंक्शन उन्हें एक्सेस कर सकें)
function delay(seconds) {
    return new Promise(resolve => setTimeout(resolve, seconds * 1000));
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Main execution
main().catch(async (error) => {
    // यह अंतिम कैच ब्लॉक है, किसी भी अंतिम अनहैंडल्ड एरर के लिए।
    console.error("⛔ स्क्रिप्ट का मुख्य निष्पादन क्रैश हुआ:", error);
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
    const telegramAlert = `🔥🔥 क्रिटिकल क्रैश! ${appFolderName}/${scriptName}:\n${error.message}\nनेटवर्क: ${hre.network.name}`;
    await sendTelegramMessage(telegramAlert);
    process.exit(1);
});

// यह uncaughtException हैंडलर बहुत ही गंभीर सिस्टम-लेवल एरर के लिए है
// जो ऊपर के किसी भी try-catch या .catch() द्वारा नहीं पकड़ी जाती हैं।
process.on('uncaughtException', async (err) => {
    console.error("🔥🔥🔥 CRITICAL UNCAUGHT EXCEPTION (GLOBAL):", err);
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
    const errorMessage = `🚨 [GLOBAL UNCAUGHT] ${appFolderName}/${scriptName} पर क्रैश हुआ:\n${err.message}`;
    await sendTelegramMessage(errorMessage);
    process.exit(1);
});
