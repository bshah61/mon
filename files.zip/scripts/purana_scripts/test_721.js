import { fileURLToPath } from 'url';
import { dirname } from 'path';
import hre from "hardhat";
import fs from "fs";
import axios from "axios";
import { create } from "@web3-storage/w3up-client";
import { File } from 'formdata-node';
import path from 'path';
import readline from 'readline';

// Hardhat के ethers ऑब्जेक्ट को सीधे इम्पोर्ट करें
const { ethers } = hre;

// *** नया: लोकल इमेज फ़ोल्डर का पाथ ***
const LOCAL_IMAGES_FOLDER = './images';

// नई फाइलों से डेटा लोड करें
// ये फ़ाइलें भी ESM होनी चाहिए या .cjs एक्सटेंशन में होनी चाहिए
import { prefixes, suffixes } from './nftNames.js'; // .js एक्सटेंशन जोड़ें
import {
  elements,
  generateRandomDescription,
  getRandomRarity,
  getRandomGeneration,
  getRandomElement,
  getRandomPowerLevel
} from './nftAttributes.js'; // .js एक्सटेंशन जोड़ें

const IPFS_GATEWAY = process.env.IPFS_GATEWAY || "https://ipfs.io/ipfs/";
const GIPHY_API_KEY = process.env.GIPHY_API_KEY; // Giphy API Key को .env से इम्पोर्ट करें

// Files for state management
const STATE_FILE = 'deploy-state.json';
const LOG_FILE = 'deployment-history.json';

// Validate environment variables
if (!process.env.RECEIVER_ADDRESS) {
  console.error("❌ Critical Error: Missing required .env variables (RECEIVER_ADDRESS)");
  process.exit(1);
}

// Giphy API Key का भी वैलिडेशन करें, लेकिन अब यह वैकल्पिक है अगर लोकल इमेजेस हैं
if (!GIPHY_API_KEY) {
  console.warn("⚠️ Warning: GIPHY_API_KEY is missing in .env file. Will fallback to local images if Giphy API is needed.");
}

// w3up क्लाइंट इंस्टेंस
let client;

// टारगेट स्पेस DID (जो आप चाहते हैं: tester space)
const TARGET_SPACE_DID = "did:key:z6MkiSTiF3f7HC8LCQ1pubP97VRhV4jf8FKGYzJV3hr6fB1i";

// w3up क्लाइंट को इनिशियलाइज़ और प्रमाणित करने का फ़ंक्शन
async function initializeW3upClient() {
  console.log("Setting up w3up client...");

  client = await create();

  console.log("Attempting to log in w3up client...");
  try {
    const agent = await client.login(process.env.W3UP_EMAIL);
    console.log(`w3up client logged in as: ${agent.did()}`);
  } catch (loginError) {
    console.error(`❌ Error logging in w3up client: ${loginError.message}`);
    console.error("Please ensure your w3up login is active via 'w3up login <email>' command.");
    process.exit(1);
  }

  try {
    await client.setCurrentSpace(TARGET_SPACE_DID);
    console.log(`Using explicitly set w3up space: ${TARGET_SPACE_DID}`);
  } catch (error) {
    console.error(`❌ Error setting desired w3up space (${TARGET_SPACE_DID}):`, error.message);
    console.log("Attempting to use the first available space or create a new one as a fallback.");

    const spaces = await client.spaces();

    if (spaces.length === 0) {
      console.log("No w3up space found. Creating a new one named 'my-nft-deployments'...");
      const newSpace = await client.createSpace('my-nft-deployments');
      await newSpace.save();
      await client.setCurrentSpace(newSpace.did());
      console.log(`New w3up space created and set: ${newSpace.did()}`);
    } else {
      const firstSpace = spaces[0];
      await client.setCurrentSpace(firstSpace.did());
      console.log(`Using existing w3up space: ${firstSpace.did()} (as desired space could not be explicitly set)`);
    }
  }

  console.log("w3up client initialized and space set.");
}

// Random name and symbol generator
function getRandomName() {
  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
  return `${prefix}${suffix}`;
}
function getRandomSymbol() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const length = Math.floor(Math.random() * 3) + 3;
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}
function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// सेकंड को HHh MMm SSs फॉर्मेट में बदलने के लिए हेल्पर फंक्शन
function formatSecondsToHMS(totalSeconds) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  let parts = [];
  if (hours > 0) parts.push(`${hours}h`);
  // मिनट दिखाएँ अगर घंटे 0 से ज़्यादा हैं, या अगर मिनट 0 से ज़्यादा हैं
  if (minutes > 0 || hours > 0) parts.push(`${minutes}m`);
  parts.push(`${seconds.toString().padStart(2, '0')}s`); // सेकंड हमेशा 2 अंकों में दिखाएँ

  return parts.join(' ');
}

// यह फंक्शन दिए गए कुल सेकंड्स के लिए लाइव काउंटडाउन करेगा
async function countdownLive(prefixMessage, totalSeconds) {
  let remainingSeconds = totalSeconds;

  return new Promise(resolve => {
    if (remainingSeconds < 0) remainingSeconds = 0;

    // तुरंत पहला अपडेट दिखाएं ताकि कोई शुरुआती खालीपन न हो
    readline.clearLine(process.stdout, 0);
    readline.cursorTo(process.stdout, 0);
    let formattedTime = formatSecondsToHMS(remainingSeconds);
    process.stdout.write(`${prefixMessage} ${formattedTime} left...`);

    // अगर समय 0 या उससे कम है तो तुरंत खत्म करें, इंटरवल शुरू करने की जरूरत नहीं
    if (remainingSeconds <= 0) {
      console.log(); // नई लाइन पर जाएं
      return resolve();
    }

    remainingSeconds--; // पहले अपडेट के बाद एक सेकंड घटाएं

    const interval = setInterval(() => {
      readline.clearLine(process.stdout, 0);
      readline.cursorTo(process.stdout, 0);

      formattedTime = formatSecondsToHMS(remainingSeconds);
      process.stdout.write(`${prefixMessage} ${formattedTime} left...`);

      if (remainingSeconds <= 0) {
        clearInterval(interval);
        console.log(); // नई लाइन पर जाएं ताकि अगला लॉग साफ दिखे
        resolve();
      }
      remainingSeconds--;
    }, 1000);
  });
}

// <--- यहाँ नया कोड जोड़ना खत्म करें --->

async function delay(seconds) { // `showCountdown` पैरामीटर अब यहाँ नहीं है
  await new Promise(resolve => setTimeout(resolve, seconds * 1000));
}

function saveState(state) {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}
function loadState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE));
  } catch {
    return null;
  }
}
async function logDeployment(details) {
  let history = [];
  try {
    history = JSON.parse(fs.readFileSync(LOG_FILE));
  } catch (e) { }
  history.push({
    timestamp: new Date().toISOString(),
    ...details
  });
  fs.writeFileSync(LOG_FILE, JSON.stringify(history, null, 2));
}

// ⏰ For testing: simulate "midnight" at 00:00 UTC
function getMsToMidnight() {
  const now = new Date();
  const target = new Date(
    now.getUTCFullYear(),
    now.getUTCMonth(),
    now.getUTCDate(),
    0, 0, 0 // 00:00 UTC
  );
  if (now > target) {
    target.setUTCDate(target.getUTCDate() + 1);
  }
  return target - now;
}

// --- नया फ़ंक्शन: लोकल इमेज फ़ोल्डर से रैंडम फ़ाइल चुनें ---
async function getRandomLocalImageFile() {
  try {
    if (!fs.existsSync(LOCAL_IMAGES_FOLDER)) {
      console.error(`❌ Local images folder not found at: ${LOCAL_IMAGES_FOLDER}`);
      return null;
    }

    const files = fs.readdirSync(LOCAL_IMAGES_FOLDER).filter(file => {
      const ext = path.extname(file).toLowerCase();
      // PNG, JPG, JPEG, GIF जैसे सामान्य इमेज एक्सटेंशन को सपोर्ट करें
      return ['.png', '.jpg', '.jpeg', '.gif'].includes(ext);
    });

    if (files.length === 0) {
      console.error(`❌ No image files found in local folder: ${LOCAL_IMAGES_FOLDER}`);
      return null;
    }

    const randomFile = files[Math.floor(Math.random() * files.length)];
    const filePath = path.join(LOCAL_IMAGES_FOLDER, randomFile);
    console.log(`🖼️ Using random local image: ${filePath}`);

    const imageBuffer = fs.readFileSync(filePath);
    const mimeType = `image/${path.extname(randomFile).substring(1)}`; // .png -> image/png
    return new File([imageBuffer], randomFile, { type: mimeType });

  } catch (error) {
    console.error("Error getting random local image:", error);
    return null;
  }
}

async function uploadImageToWeb3Storage(tokenId) {
  let imageUrl = null;
  let imageFile = null;

  // Giphy API से इमेज डाउनलोड करने का प्रयास करें
  if (GIPHY_API_KEY) {
    try { // <-- यहाँ नया try ब्लॉक शुरू होता है
      console.log(`\nSearching for a random GIF for token #${tokenId} with tags 'happy pixel smolverse' from Giphy...`);
      // Giphy API के 'random' एंडपॉइंट का उपयोग करें, जिसमें `tag` पैरामीटर 'happy pixel smolverse' सेट है।
      // स्पेस के साथ टैग देने पर Giphy उन्हें अलग-अलग कीवर्ड के रूप में देखता है।
      const giphySearchTag = "happy pixel smolverse";
      const giphyApiUrl = `https://api.giphy.com/v1/gifs/random?api_key=${GIPHY_API_KEY}&tag=${giphySearchTag}`;

      const giphyResponse = await axios.get(giphyApiUrl);

      // Giphy के रिस्पॉन्स में 'data' एरे में GIFs की लिस्ट होती है।
      // यदि `random` एंडपॉइंट एक ही GIF देता है (जो आमतौर पर होता है),
      // तो हम सीधे उसके `images.preview_gif.url` का उपयोग कर सकते हैं।
      // यदि भविष्य में आप `search` एंडपॉइंट का उपयोग करते हैं और कई परिणाम आते हैं,
      // तो आपको सबसे छोटे साइज़ वाली GIF को चुनने के लिए एक लूप चलाना होगा।

      // अभी के लिए, हम सीधे 'preview_gif.url' का उपयोग कर रहे हैं जो आमतौर पर छोटे साइज़ का होता है।
      const gifUrl = giphyResponse.data.data.images.preview_gif.url;

      if (!gifUrl) {
        throw new Error(`Could not get random GIF with tag '${giphySearchTag}' from Giphy API response.`);
      }

      console.log(`Found GIF from Giphy (Tags: '${giphySearchTag}'): ${gifUrl}`);

      const tempDir = "./temp";
      if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
      // GIF के लिए .gif एक्सटेंशन का उपयोग करें
      const tempPath = `${tempDir}/nft-image-${tokenId}.gif`;

      console.log(`Attempting to download GIF from: ${gifUrl}`);
      // GIF डेटा को 'arraybuffer' के रूप में डाउनलोड करें
      const response = await axios.get(gifUrl, { responseType: 'arraybuffer' });
      fs.writeFileSync(tempPath, response.data);
      console.log(`GIF downloaded and saved to: ${tempPath}`);

      const imageBuffer = fs.readFileSync(tempPath);
      // MIME प्रकार को 'image/gif' में बदला गया है
      imageFile = new File([imageBuffer], `nft-image-${tokenId}.gif`, { type: 'image/gif' }); // <-- imageFile को असाइन करें

      fs.unlinkSync(tempPath); // अस्थायी फ़ाइल हटा दें
      console.log(`Temporary GIF file removed: ${tempPath}`); // <-- मैसेज अपडेट किया

    } catch (giphyError) { // <-- Giphy API के लिए catch ब्लॉक
      console.warn(`⚠️ Error fetching/downloading GIF from Giphy: ${giphyError.message}. Attempting to use a local image.`);
      imageFile = await getRandomLocalImageFile(); // Giphy से गलती होने पर लोकल फ़ाइल का उपयोग करें
      if (!imageFile) {
        throw new Error("GIPHY_API_KEY is set but Giphy failed, and no local images found.");
      }
    }
  } else {
    console.warn("⚠️ GIPHY_API_KEY is not set. Attempting to use a local image directly.");
    imageFile = await getRandomLocalImageFile(); // Giphy API Key न होने पर सीधे लोकल फ़ाइल का उपयोग करें
    if (!imageFile) {
      throw new Error("GIPHY_API_KEY is not set and no local images found.");
    }
  }

  if (imageFile) {
    console.log(`Uploading image for token #${tokenId} to web3.storage (via w3up)...`);
    try {
      const cid = await client.uploadFile(imageFile);
      imageUrl = `${IPFS_GATEWAY}${cid}`;
      console.log(`Image uploaded to web3.storage. CID: ${cid}`);
      return imageUrl;
    } catch (uploadError) {
      console.error("Image upload to web3.storage failed:", uploadError);
      throw uploadError;
    }
  } else {
    throw new Error("No image file prepared for upload.");
  }
}

async function createNexusMetadata(tokenId, imageUrl, nftName) {
  try {
    const metadata = {
      name: nftName,
      description: generateRandomDescription(tokenId),
      image: imageUrl,
      attributes: [
        { trait_type: "Rarity", value: getRandomRarity() },
        { trait_type: "Generation", value: getRandomGeneration(), display_type: "number" },
        { trait_type: "Element", value: getRandomElement() },
        { trait_type: "Power Level", value: getRandomPowerLevel(), display_type: "number" }
      ]
    };

    const metadataFileName = `nft-metadata-${tokenId}.json`;
    const metadataString = JSON.stringify(metadata, null, 2);

    console.log(`Uploading metadata for token #${tokenId} to web3.storage (via w3up):`, metadataString);

    const metadataFile = new File([metadataString], metadataFileName, { type: 'application/json' });

    const cid = await client.uploadFile(metadataFile);
    console.log(`Metadata uploaded to web3.storage. CID: ${cid}`);

    return `${IPFS_GATEWAY}${cid}`;
  } catch (error) {
    console.error("Metadata upload failed:", error);
    throw error;
  }
}

// Deploy function
async function deployOnce() {
  try {
    const [deployer] = await ethers.getSigners();
    const nftName = getRandomName();
    const nftSymbol = getRandomSymbol();
    const receiver = process.env.RECEIVER_ADDRESS;

    console.log(`\n🚀 Deploying NFT: ${nftName} (${nftSymbol})`);
    const NFT = await ethers.getContractFactory("MyNFT");
    // कॉन्ट्रैक्ट डिप्लॉय करते समय constructor parameters को सही क्रम में पास करें
    // MyNFT constructor: (name, symbol, initialOwner)
    const nft = await NFT.deploy(nftName, nftSymbol, deployer.address);
    await nft.waitForDeployment();
    const contractAddress = await nft.getAddress();
    console.log(`✅ Deployed at: ${contractAddress}`);

    const mintCount = getRandomInt(2, 5);
    let transferredTokenIdForSummary = null;
    const tokenIds = [];

    for (let i = 0; i < mintCount; i++) {
      try {
        const tokenIdSeed = Math.floor(Math.random() * (77777 - 3 + 1)) + 3;
        console.log(`\n📤 Uploading image for token (using seed #${tokenIdSeed})...`);
        const imageUrl = await uploadImageToWeb3Storage(tokenIdSeed);
        console.log(`Image URL: ${imageUrl}`);

        console.log(`\n📝 Creating metadata for token (using seed #${tokenIdSeed})...`);
        const metadataUrl = await createNexusMetadata(tokenIdSeed, imageUrl, nftName);
        console.log(`Metadata URL: ${metadataUrl}`);

        console.log(`Attempting to **mint and set URI** for token to ${deployer.address} with URI: ${metadataUrl}...`);

        // MyNFT कॉन्ट्रैक्ट का नया mintAndSetURI फंक्शन कॉल करें
        const tx = await nft.mintAndSetURI(deployer.address, metadataUrl);
        const receipt = await tx.wait();

        // मिंटेड टोकन आईडी को `Transfer` इवेंट से प्राप्त करें
        const event = receipt.logs
          .map(log => { try { return nft.interface.parseLog(log); } catch { return null; } })
          .find(e => e && e.name === "Transfer");

        if (!event) throw new Error("No Transfer event found in mint transaction receipt.");
        const mintedTokenId = event.args.tokenId.toString();
        tokenIds.push(mintedTokenId);

        console.log(`🖼️ Successfully minted token #${mintedTokenId} and set URI in a **single transaction**! | Tx: ${tx.hash}`);

        // सत्यापन के लिए tokenURI को कॉल करें (वैकल्पिक, लेकिन अच्छा)
        const currentTokenURI = await nft.tokenURI(mintedTokenId);
        console.log(`*** VERIFICATION: Token URI after mintAndSetURI for #${mintedTokenId} is: ${currentTokenURI} ***`);

        if (i < mintCount - 1) {
          const waitTime = getRandomInt(5, 26);
          await countdownLive(`⏳ Waiting before next mint`, waitTime);
          console.log();
        }

      } catch (e) {
        console.error(`⚠️ Mint or metadata upload failed for token ${i + 1}: ${e.message}`);
        if (e.reason) console.error(`Reason: ${e.reason}`);
      }
    }

    const mainWaitTime = getRandomInt(60, 300);
    await countdownLive(`⏳ Waiting before transfer`, mainWaitTime);
    console.log();

    if (tokenIds.length > 0) {
      const randomTokenId = tokenIds[Math.floor(Math.random() * tokenIds.length)];
      let transferSuccess = false;

      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          console.log(`Attempting to transfer token #${randomTokenId} to ${receiver} (Attempt ${attempt})...`);
          const tx = await nft.transferFrom(deployer.address, receiver, randomTokenId);
          await tx.wait();
          console.log(`📤 Successfully transferred token #${randomTokenId} to ${receiver}`);
          transferredTokenIdForSummary = randomTokenId;
          transferSuccess = true;
          break;
        } catch (e) {
          console.warn(`⚠️ Transfer attempt ${attempt} failed: ${e.message}`);
          if (attempt < 2) await delay(10);
        }
      }

      if (!transferSuccess) {
        console.error(`❌ Transfer failed after 2 attempts`);
      }
    } else {
      console.log("ℹ️ No tokens minted, skipping transfer");
    }

    const summary = {
      contractAddress,
      nftName,
      nftSymbol,
      deployer: deployer.address,
      receiver,
      mintedTokens: tokenIds.length,
      tokenIds,
      transferredToken: transferredTokenIdForSummary
    };

    console.log("\n💎 Summary:");
    console.log(JSON.stringify(summary, null, 2));
    await logDeployment(summary);
    return summary;

  } catch (e) {
    console.error("🚨 Deployment error:", e.message);
    throw e;
  }
}

// temp डायरेक्टरी को साफ और सुनिश्चित करने का फ़ंक्शन
async function cleanTempDirectory() {
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = dirname(__filename);

  const tempDir = path.join(__dirname, '..', 'temp');
  if (fs.existsSync(tempDir)) {
    console.log(`Cleaning existing temp directory: ${tempDir}`);
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
  console.log(`Ensuring temp directory exists: ${tempDir}`);
  fs.mkdirSync(tempDir, { recursive: true });
}

// Main loop
async function main() {
  process.on('SIGINT', () => {
    console.log('\n🔴 Shutdown signal received. Exiting...');
    process.exit(0);
  });

  await initializeW3upClient();

  await cleanTempDirectory();

  while (true) {
    const msToMidnight = getMsToMidnight();
    const secondsToMidnight = Math.ceil(msToMidnight / 1000);

    // वर्तमान UTC समय और लक्ष्य 00:00 UTC (आपके getMsToMidnight फंक्शन के आधार पर 07:42) को फॉर्मेट करें
    const now = new Date();
    const targetUtcTime = new Date(
      now.getUTCFullYear(),
      now.getUTCMonth(),
      now.getUTCDate(),
      0, 0, 0 // यह आपके getMsToMidnight फ़ंक्शन के अनुसार है (00:00 UTC+7:42)
    );
    if (now.getTime() > targetUtcTime.getTime()) {
      targetUtcTime.setUTCDate(targetUtcTime.getUTCDate() + 1); // अगर समय बीत गया है, तो अगले दिन पर सेट करें
    }
    const targetTimeFormatted = targetUtcTime.toISOString().substring(11, 16); // HH:MM (उदाहरण: "07:42")

    await countdownLive(`⏳ Waiting until ${targetTimeFormatted} UTC`, secondsToMidnight);
    console.log(); // यह अपनी जगह रहेगा

    const timesToRun = getRandomInt(1, 3);
    console.log(`\n📅 New simulated day! Will deploy ${timesToRun} time(s)`);

    const usedDelays = new Set();

    for (let i = 0; i < timesToRun; i++) {
      let delayBetween = getRandomInt(1 *13, 1 * 31); // यह सिर्फ 31 सेकंड से 31 सेकंड के बीच ही रुकेगा?
                                                            // क्या आप यहाँ 2 से 6 घंटे का डिले चाहते थे?
                                                            // अगर हाँ, तो यह होना चाहिए: getRandomInt(2 * 3600, 6 * 3600);
      while (usedDelays.has(delayBetween)) {
        delayBetween = getRandomInt(2 * 3600, 6 * 3600);
      }
      usedDelays.add(delayBetween);

      await countdownLive(`⏱️ Waiting before deployment ${i + 1}`, delayBetween);
      console.log(); // यह अपनी जगह रहेगा

      console.log(`\n--- Deployment ${i + 1}/${timesToRun} ---`);
      const result = await deployOnce();
      saveState(result);
    }
  }
}

main();


//import { fileURLToPath } from 'url'; // 'url' मॉड्यूल से fileURLToPath इम्पोर्ट करें

// 👇 यहीं से Telegram Crash Notifier शुरू करें
process.on('uncaughtException', async (err) => {
  console.error("🔥 CRITICAL ERROR:", err);

  const fileUrl = import.meta.url;
  const scriptFullPath = fileURLToPath(fileUrl);

  // अब हम एक स्तर और ऊपर जाएंगे ताकि 'joseph-monad' मिल सके
  // पहले scriptFullPath से फाइल का नाम हटाते हैं (जैसे 13.js)
  const scriptDirectory = path.dirname(scriptFullPath); // देगा: /joseph-monad/scripts

  // फिर scripts डायरेक्टरी की पैरेंट डायरेक्टरी पर जाते हैं
  const grandParentDirectory = path.dirname(scriptDirectory); // देगा: /joseph-monad

  // अब grandParentDirectory का नाम निकालते हैं (जैसे: joseph-monad)
  const appFolderName = path.basename(grandParentDirectory);
  
  // स्क्रिप्ट का नाम निकालें (जैसे: 13.js)
  const scriptName = path.basename(scriptFullPath);

  try {
    await axios.post(`https://api.telegram.org/bot7620164559:AAHq5ftIl5kUIjehdvyyrXyD0hd9QAGTY3s/sendMessage`, {
      chat_id: "1239205720",
      text: `🚨 ${appFolderName}/${scriptName} पर क्रैश हुआ:\n${err.message}`
    });
  } catch (e) {
    console.error("❌ Failed to send Telegram alert:", e.message);
  }

  process.exit(1);
});
