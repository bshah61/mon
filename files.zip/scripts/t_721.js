import { fileURLToPath } from 'url';
import { dirname } from 'path'; // dirname को path से इम्पोर्ट करें
import hre from "hardhat";
import fs from "fs";
import axios from "axios";
import { create } from "@web3-storage/w3up-client";
import { File } from 'formdata-node';
import path from 'path'; // path मॉड्यूल को भी इम्पोर्ट करें
import readline from 'readline';
import os from 'os'; // 'os' मॉड्यूल को यहाँ इंपोर्ट करें

// Hardhat के ethers ऑब्जेक्ट को सीधे इम्पोर्ट करें
const { ethers } = hre;

// *** नया: टाइमस्टैम्प के साथ लॉगिंग के लिए हेल्पर फ़ंक्शन (DD-MM-YY HH:MM UTC) ***
function logWithTimestamp(message) {
    const now = new Date();
    const day = String(now.getUTCDate()).padStart(2, '0');
    const month = String(now.getUTCMonth() + 1).padStart(2, '0');
    const year = String(now.getUTCFullYear()).slice(-2);
    const hours = String(now.getUTCHours()).padStart(2, '0');
    const minutes = String(now.getUTCMinutes()).padStart(2, '0');

    console.log(`[${day}-${month}-${year} ${hours}:${minutes} UTC] ${message}`);
}

// *** नया: लोकल इमेज फ़ोल्डर का पाथ ***
const LOCAL_IMAGES_FOLDER = './images';

// नई फाइलों से डेटा लोड करें
import { prefixes, suffixes } from './nftNames.js';
import {
  elements,
  generateRandomDescription,
  getRandomRarity,
  getRandomGeneration,
  getRandomElement,
  getRandomPowerLevel
} from './nftAttributes.js';

const IPFS_GATEWAY = process.env.IPFS_GATEWAY || "https://ipfs.io/ipfs/";
const GIPHY_API_KEY = process.env.GIPHY_API_KEY;

// *** अपडेटेड: 'data' डायरेक्टरी में फ़ाइलें ***
const DATA_DIR = './data';
const STATE_FILE = path.join(DATA_DIR, 'deploy-state-721.json');
const LOG_FILE = path.join(DATA_DIR, 'deployment-history-721.json');

// *** नया: 'data' डायरेक्टरी बनाने का लॉजिक यहाँ जोड़ा गया है ***
try {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
        logWithTimestamp(`✅ 'data' डायरेक्टरी बनाई गई: ${DATA_DIR}`);
    } else {
        logWithTimestamp(`ℹ️ 'data' डायरेक्टरी पहले से मौजूद है: ${DATA_DIR}`);
    }
} catch (e) {
    logWithTimestamp(`❌ 'data' डायरेक्टरी बनाने में एरर: ${e.message}`);
    const hostname = os.hostname();
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
    sendTelegramMessage(`🚨 ${hostname} - ${appFolderName}/${scriptName} में 'data' डायरेक्टरी बनाने की एरर:\n${e.message}`);
    process.exit(1);
}
// *** यहाँ तक नया लॉजिक ***


// Validate environment variables
if (!process.env.RECEIVER_ADDRESS) {
  logWithTimestamp("❌ Critical Error: Missing required .env variables (RECEIVER_ADDRESS)");
  process.exit(1);
}

// Giphy API Key का भी वैलिडेशन करें, लेकिन अब यह वैकल्पिक है अगर लोकल इमेजेस हैं
if (!GIPHY_API_KEY) {
  logWithTimestamp("⚠️ Warning: GIPHY_API_KEY is missing in .env file. Will fallback to local images if Giphy API is needed.");
}

// w3up क्लाइंट इंस्टेंस
let client;

// टारगेट स्पेस DID (जो आप चाहते हैं: tester space)
const TARGET_SPACE_DID = "did:key:z6MkiSTiF3f7HC8LCQ1pubP97VRhV4jf8FKGYzJV3hr6fB1i";

// 👇 यहाँ से Telegram Crash Notifier शुरू करें - यह अब सिर्फ एक बार है
process.on('uncaughtException', async (err) => {
  logWithTimestamp("🔥 CRITICAL UNCAUGHT EXCEPTION (GLOBAL):", err);

  const fileUrl = import.meta.url;
  const scriptFullPath = fileURLToPath(fileUrl);

  const scriptDirectory = path.dirname(scriptFullPath);
  const grandParentDirectory = path.dirname(scriptDirectory);
  const appFolderName = path.basename(grandParentDirectory);
  const scriptName = path.basename(scriptFullPath);
  const hostname = os.hostname();

  const formattedAppName = `${hostname}-/${appFolderName}-${scriptName}`;

  try {
    await axios.post(`https://api.telegram.org/bot7620164559:AAHq5ftIl5kUIjehdvyyrXyD0hd9QAGTY3s/sendMessage`, {
      chat_id: "1239205720",
      text: `🚨 ${formattedAppName} पर क्रैश हुआ:\n${err.message}`
    });
  } catch (e) {
    logWithTimestamp("❌ Failed to send Telegram alert:", e.message);
  }

  process.exit(1);
});
// 👆 यहाँ Telegram Crash Notifier खत्म होता है

// w3up क्लाइंट को इनिशियलाइज़ और प्रमाणित करने का फ़ंक्शन
async function initializeW3upClient() {
  logWithTimestamp("Setting up w3up client...");

  client = await create();

  logWithTimestamp("Attempting to log in w3up client...");
  try {
    const agent = await client.login(process.env.W3UP_EMAIL);
    logWithTimestamp(`w3up client logged in as: ${agent.did()}`);
  } catch (loginError) {
    logWithTimestamp(`❌ Error logging in w3up client: ${loginError.message}`);
    logWithTimestamp("Please ensure your w3up login is active via 'w3up login <email>' command.");
    process.exit(1);
  }

  try {
    await client.setCurrentSpace(TARGET_SPACE_DID);
    logWithTimestamp(`Using explicitly set w3up space: ${TARGET_SPACE_DID}`);
  } catch (error) {
    logWithTimestamp(`❌ Error setting desired w3up space (${TARGET_SPACE_DID}): ${error.message}`);
    logWithTimestamp("Attempting to use the first available space or create a new one as a fallback.");

    const spaces = await client.spaces();

    if (spaces.length === 0) {
      logWithTimestamp("No w3up space found. Creating a new one named 'my-nft-deployments'...");
      const newSpace = await client.createSpace('my-nft-deployments');
      await newSpace.save();
      await client.setCurrentSpace(newSpace.did());
      logWithTimestamp(`New w3up space created and set: ${newSpace.did()}`);
    } else {
      const firstSpace = spaces[0];
      await client.setCurrentSpace(firstSpace.did());
      logWithTimestamp(`Using existing w3up space: ${firstSpace.did()} (as desired space could not be explicitly set)`);
    }
  }

  logWithTimestamp("w3up client initialized and space set.");
}

// Random name and symbol generator
function getRandomName() {
  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
  return `${prefix}${suffix}`;
}
function getRandomSymbol() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const length = Math.floor(Math.random() * 3) + 3;
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}
function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// सेकंड को HHh MMm SSs फॉर्मेट में बदलने के लिए हेल्पर फंक्शन
function formatSecondsToHMS(totalSeconds) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  let parts = [];
  if (hours > 0) parts.push(`${hours}h`);
  if (minutes > 0 || hours > 0) parts.push(`${minutes}m`);
  parts.push(`${seconds.toString().padStart(2, '0')}s`);

  return parts.join(' ');
}

// यह फंक्शन दिए गए कुल सेकंड्स के लिए लाइव काउंटडाउन करेगा
async function countdownLive(prefixMessage, totalSeconds) {
  let remainingSeconds = totalSeconds;

  return new Promise(resolve => {
    if (remainingSeconds < 0) remainingSeconds = 0;

    readline.clearLine(process.stdout, 0);
    readline.cursorTo(process.stdout, 0);
    let formattedTime = formatSecondsToHMS(remainingSeconds);
    process.stdout.write(`${prefixMessage} ${formattedTime} left...`);

    if (remainingSeconds <= 0) {
      console.log();
      return resolve();
    }

    remainingSeconds--;

    const interval = setInterval(() => {
      readline.clearLine(process.stdout, 0);
      readline.cursorTo(process.stdout, 0);

      formattedTime = formatSecondsToHMS(remainingSeconds);
      process.stdout.write(`${prefixMessage} ${formattedTime} left...`);

      if (remainingSeconds <= 0) {
        clearInterval(interval);
        console.log();
        resolve();
      }
      remainingSeconds--;
    }, 1000);
  });
}

async function delay(seconds) {
  await new Promise(resolve => setTimeout(resolve, seconds * 1000));
}

// *** नया: saveState फ़ंक्शन (20.js से इम्प्रूव्ड वर्जन) ***
async function saveState(stateData) {
    const hostname = os.hostname();
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));

    try {
        fs.writeFileSync(STATE_FILE, JSON.stringify(stateData, null, 2));
        logWithTimestamp(`✅ State saved to ${STATE_FILE}`);
    } catch (e) {
        const errorMessage = `❌ ${STATE_FILE} में स्टेट लिखने में एरर: ${e.message}`;
        logWithTimestamp(errorMessage);
        sendTelegramMessage(`🚨 ${hostname} - ${appFolderName}/${scriptName} में स्टेट सेव करने की एरर:\n${errorMessage}`);
    }
}

function loadState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE));
  } catch {
    return null;
  }
}

// *** सुधारा गया logDeployment फ़ंक्शन (20.js से इम्प्रूव्ड वर्जन) ***
async function logDeployment(details) {
    const hostname = os.hostname();
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));

    let history = [];
    try {
        if (fs.existsSync(LOG_FILE)) {
            const fileContent = fs.readFileSync(LOG_FILE, 'utf8');
            if (fileContent.trim() !== '') {
                const parsedContent = JSON.parse(fileContent);
                if (Array.isArray(parsedContent)) {
                    history = parsedContent;
                } else {
                    logWithTimestamp(`⚠️ ${LOG_FILE} में डेटा ऐरे नहीं है। इसे रीसेट किया जा रहा है।`);
                }
            }
        }
    } catch (e) {
        const errorMessage = `❌ ${LOG_FILE} को पढ़ने या पार्स करने में एरर: ${e.message}`;
        logWithTimestamp(errorMessage);
        logWithTimestamp(`⚠️ ${LOG_FILE} को रीसेट किया जा रहा है।`);
        history = [];
        sendTelegramMessage(`🚨 ${hostname} - ${appFolderName}/${scriptName} में फ़ाइल पढ़ने की एरर:\n${errorMessage}`);
    }
    history.push({
        timestamp: new Date().toISOString(),
        ...details
    });
    try {
        fs.writeFileSync(LOG_FILE, JSON.stringify(history, null, 2));
    } catch (e) {
        const errorMessage = `❌ ${LOG_FILE} में लिखने में एरर: ${e.message}`;
        logWithTimestamp(errorMessage);
        sendTelegramMessage(`🚨 ${hostname} - ${appFolderName}/${scriptName} में फ़ाइल लिखने की एरर:\n${errorMessage}`);
    }
}

// ⏰ For testing: simulate "midnight" at 00:00 UTC
function getMsToMidnight() {
  const now = new Date();
  const target = new Date(
    now.getUTCFullYear(),
    now.getUTCMonth(),
    now.getUTCDate(),
    1, 0, 0 // 00:00 UTC
  );
  if (now > target) {
    target.setUTCDate(target.getUTCDate() + 1);
  }
  return target - now;
}

// --- नया फ़ंक्शन: लोकल इमेज फ़ोल्डर से रैंडम फ़ाइल चुनें ---
async function getRandomLocalImageFile() {
  try {
    if (!fs.existsSync(LOCAL_IMAGES_FOLDER)) {
      logWithTimestamp(`❌ Local images folder not found at: ${LOCAL_IMAGES_FOLDER}`);
      return null;
    }

    const files = fs.readdirSync(LOCAL_IMAGES_FOLDER).filter(file => {
      const ext = path.extname(file).toLowerCase();
      return ['.png', '.jpg', '.jpeg', '.gif'].includes(ext);
    });

    if (files.length === 0) {
      logWithTimestamp(`❌ No image files found in local folder: ${LOCAL_IMAGES_FOLDER}`);
      return null;
    }

    const randomFile = files[Math.floor(Math.random() * files.length)];
    const filePath = path.join(LOCAL_IMAGES_FOLDER, randomFile);
    logWithTimestamp(`🖼️ Using random local image: ${filePath}`);

    const imageBuffer = fs.readFileSync(filePath);
    const mimeType = `image/${path.extname(randomFile).substring(1)}`;
    return new File([imageBuffer], randomFile, { type: mimeType });

  } catch (error) {
    logWithTimestamp(`❌ Error getting random local image: ${error}`);
    return null;
  }
}

async function uploadImageToWeb3Storage(tokenId) {
  let imageUrl = null;
  let imageFile = null;

  if (GIPHY_API_KEY) {
    try {
      logWithTimestamp(`\nSearching for a random GIF for token #${tokenId} with tags 'happy pixel smolverse' from Giphy...`);
      const giphySearchTag = "happy pixel smolverse";
      const giphyApiUrl = `https://api.giphy.com/v1/gifs/random?api_key=${GIPHY_API_KEY}&tag=${giphySearchTag}`;

      const giphyResponse = await axios.get(giphyApiUrl);
      const gifUrl = giphyResponse.data.data.images.preview_gif.url;

      if (!gifUrl) {
        throw new Error(`Could not get random GIF with tag '${giphySearchTag}' from Giphy API response.`);
      }

      logWithTimestamp(`Found GIF from Giphy (Tags: '${giphySearchTag}'): ${gifUrl}`);

      const tempDir = "./temp";
      if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
      const tempPath = `${tempDir}/nft-image-${tokenId}.gif`;

      logWithTimestamp(`Attempting to download GIF from: ${gifUrl}`);
      const response = await axios.get(gifUrl, { responseType: 'arraybuffer' });
      fs.writeFileSync(tempPath, response.data);
      logWithTimestamp(`GIF downloaded and saved to: ${tempPath}`);

      const imageBuffer = fs.readFileSync(tempPath);
      imageFile = new File([imageBuffer], `nft-image-${tokenId}.gif`, { type: 'image/gif' });

      fs.unlinkSync(tempPath);
      logWithTimestamp(`Temporary GIF file removed: ${tempPath}`);

    } catch (giphyError) {
      logWithTimestamp(`⚠️ Error fetching/downloading GIF from Giphy: ${giphyError.message}. Attempting to use a local image.`);
      imageFile = await getRandomLocalImageFile();
      if (!imageFile) {
        throw new Error("GIPHY_API_KEY is set but Giphy failed, and no local images found.");
      }
    }
  } else {
    logWithTimestamp("⚠️ GIPHY_API_KEY is not set. Attempting to use a local image directly.");
    imageFile = await getRandomLocalImageFile();
    if (!imageFile) {
      throw new Error("GIPHY_API_KEY is not set and no local images found.");
    }
  }

  if (imageFile) {
    logWithTimestamp(`Uploading image for token #${tokenId} to web3.storage (via w3up)...`);
    try {
      const cid = await client.uploadFile(imageFile);
      imageUrl = `${IPFS_GATEWAY}${cid}`;
      logWithTimestamp(`Image uploaded to web3.storage. CID: ${cid}`);
      return imageUrl;
    } catch (uploadError) {
      logWithTimestamp("❌ Image upload to web3.storage failed:", uploadError);
      throw uploadError;
    }
  } else {
    throw new Error("No image file prepared for upload.");
  }
}

async function createNexusMetadata(tokenId, imageUrl, nftName) {
  try {
    const metadata = {
      name: nftName,
      description: generateRandomDescription(tokenId),
      image: imageUrl,
      attributes: [
        { trait_type: "Rarity", value: getRandomRarity() },
        { trait_type: "Generation", value: getRandomGeneration(), display_type: "number" },
        { trait_type: "Element", value: getRandomElement() },
        { trait_type: "Power Level", value: getRandomPowerLevel(), display_type: "number" }
      ]
    };

    const metadataFileName = `nft-metadata-${tokenId}.json`;
    const metadataString = JSON.stringify(metadata, null, 2);

    logWithTimestamp(`Uploading metadata for token #${tokenId} to web3.storage (via w3up):`);
    logWithTimestamp(metadataString); // logWithTimestamp will handle this.

    const metadataFile = new File([metadataString], metadataFileName, { type: 'application/json' });

    const cid = await client.uploadFile(metadataFile);
    logWithTimestamp(`Metadata uploaded to web3.storage. CID: ${cid}`);

    return `${IPFS_GATEWAY}${cid}`;
  } catch (error) {
    logWithTimestamp("❌ Metadata upload failed:", error);
    throw error;
  }
}

// Deploy function
async function deployOnce() {
  try {
    const [deployer] = await ethers.getSigners();
    const nftName = getRandomName();
    const nftSymbol = getRandomSymbol();
    const receiver = process.env.RECEIVER_ADDRESS;

    logWithTimestamp(`\n🚀 Deploying NFT: ${nftName} (${nftSymbol})`);
    const NFT = await ethers.getContractFactory("MyNFT");
    const nft = await NFT.deploy(nftName, nftSymbol, deployer.address);
    await nft.waitForDeployment();
    const contractAddress = await nft.getAddress();
    logWithTimestamp(`✅ Deployed at: ${contractAddress}`);

    const mintCount = getRandomInt(2, 5);
    let transferredTokenIdForSummary = null;
    const tokenIds = [];

    for (let i = 0; i < mintCount; i++) {
      try {
        const tokenIdSeed = Math.floor(Math.random() * (77777 - 3 + 1)) + 3;
        logWithTimestamp(`\n📤 Uploading image for token (using seed #${tokenIdSeed})...`);
        const imageUrl = await uploadImageToWeb3Storage(tokenIdSeed);
        logWithTimestamp(`Image URL: ${imageUrl}`);

        logWithTimestamp(`\n📝 Creating metadata for token (using seed #${tokenIdSeed})...`);
        const metadataUrl = await createNexusMetadata(tokenIdSeed, imageUrl, nftName);
        logWithTimestamp(`Metadata URL: ${metadataUrl}`);

        logWithTimestamp(`Attempting to **mint and set URI** for token to ${deployer.address} with URI: ${metadataUrl}...`);

        const tx = await nft.mintAndSetURI(deployer.address, metadataUrl);
        const receipt = await tx.wait();

        const event = receipt.logs
          .map(log => { try { return nft.interface.parseLog(log); } catch { return null; } })
          .find(e => e && e.name === "Transfer");

        if (!event) throw new Error("No Transfer event found in mint transaction receipt.");
        const mintedTokenId = event.args.tokenId.toString();
        tokenIds.push(mintedTokenId);

        logWithTimestamp(`🖼️ Successfully minted token #${mintedTokenId} and set URI in a **single transaction**! | Tx: ${tx.hash}`);

        const currentTokenURI = await nft.tokenURI(mintedTokenId);
        logWithTimestamp(`*** VERIFICATION: Token URI after mintAndSetURI for #${mintedTokenId} is: ${currentTokenURI} ***`);

        if (i < mintCount - 1) {
          const waitTime = getRandomInt(5, 26);
          await countdownLive(`⏳ Waiting before next mint`, waitTime);
          console.log(); // यह readline.clearLine के बाद नई लाइन के लिए है
        }

      } catch (e) {
        logWithTimestamp(`⚠️ Mint or metadata upload failed for token ${i + 1}: ${e.message}`);
        if (e.reason) logWithTimestamp(`Reason: ${e.reason}`);
      }
    }

    const mainWaitTime = getRandomInt(60, 300);
    await countdownLive(`⏳ Waiting before transfer`, mainWaitTime);
    console.log(); // यह readline.clearLine के बाद नई लाइन के लिए है

    if (tokenIds.length > 0) {
      const randomTokenId = tokenIds[Math.floor(Math.random() * tokenIds.length)];
      let transferSuccess = false;

      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          logWithTimestamp(`Attempting to transfer token #${randomTokenId} to ${receiver} (Attempt ${attempt})...`);
          const tx = await nft.transferFrom(deployer.address, receiver, randomTokenId);
          await tx.wait();
          logWithTimestamp(`📤 Successfully transferred token #${randomTokenId} to ${receiver}`);
          transferredTokenIdForSummary = randomTokenId;
          transferSuccess = true;
          break;
        } catch (e) {
          logWithTimestamp(`⚠️ Transfer attempt ${attempt} failed: ${e.message}`);
          if (attempt < 2) await delay(10);
        }
      }

      if (!transferSuccess) {
        logWithTimestamp(`❌ Transfer failed after 2 attempts`);
      }
    } else {
      logWithTimestamp("ℹ️ No tokens minted, skipping transfer");
    }

    const summary = {
      contractAddress,
      nftName,
      nftSymbol,
      deployer: deployer.address,
      receiver,
      mintedTokens: tokenIds.length,
      tokenIds,
      transferredToken: transferredTokenIdForSummary
    };

    logWithTimestamp("\n💎 Summary:");
    logWithTimestamp(JSON.stringify(summary, null, 2)); // logWithTimestamp will handle this.
    await logDeployment(summary);
    return summary;

  } catch (e) {
    logWithTimestamp(`🚨 Deployment error: ${e.message}`);
    throw e;
  }
}

// temp डायरेक्टरी को साफ और सुनिश्चित करने का फ़ंक्शन
async function cleanTempDirectory() {
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = dirname(__filename);

  const tempDir = path.join(__dirname, '..', 'temp');
  if (fs.existsSync(tempDir)) {
    logWithTimestamp(`Cleaning existing temp directory: ${tempDir}`);
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
  logWithTimestamp(`Ensuring temp directory exists: ${tempDir}`);
  fs.mkdirSync(tempDir, { recursive: true });
}

// Main loop
async function main() {
  process.on('SIGINT', () => {
    logWithTimestamp('\n🔴 Shutdown signal received. Exiting...');
    process.exit(0);
  });

  await initializeW3upClient();

  await cleanTempDirectory();

  while (true) {
    const msToMidnight = getMsToMidnight();
    const secondsToMidnight = Math.ceil(msToMidnight / 1000);

    const now = new Date();
    const targetUtcTime = new Date(
      now.getUTCFullYear(),
      now.getUTCMonth(),
      now.getUTCDate(),
      0, 0, 0
    );
    if (now.getTime() > targetUtcTime.getTime()) {
      targetUtcTime.setUTCDate(targetUtcTime.getUTCDate() + 1);
    }
    const targetTimeFormatted = targetUtcTime.toISOString().substring(11, 16);

    await countdownLive(`⏳ Waiting until ${targetTimeFormatted} UTC`, secondsToMidnight);
    console.log(); // यह readline.clearLine के बाद नई लाइन के लिए है

    const timesToRun = getRandomInt(1, 3);
    logWithTimestamp(`\n📅 New simulated day! Will deploy ${timesToRun} time(s)`);

    const usedDelays = new Set();

    for (let i = 0; i < timesToRun; i++) {
      let delayBetween = getRandomInt(1 * 13, 1 * 31);
      while (usedDelays.has(delayBetween)) {
        delayBetween = getRandomInt(2 * 3600, 6 * 3600);
      }
      usedDelays.add(delayBetween);

      await countdownLive(`⏱️ Waiting before deployment ${i + 1}`, delayBetween);
      console.log(); // यह readline.clearLine के बाद नई लाइन के लिए है

      logWithTimestamp(`\n--- Deployment ${i + 1}/${timesToRun} ---`);
      const result = await deployOnce();
      // saveState(result); // पुराने डायरेक्ट कॉल की जगह अब फ़ंक्शन का उपयोग करें
      await saveState(result); // Updated to use the new async saveState function
    }
  }
}

main().catch(async (error) => {
    const hostname = os.hostname();
    logWithTimestamp(`⛔ स्क्रिप्ट का मुख्य निष्पादन क्रैश हुआ: ${error}`);
    const scriptName = path.basename(fileURLToPath(import.meta.url));
    const appFolderName = path.basename(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
    const telegramAlert = `🔥🔥 ${hostname} - क्रिटिकल क्रैश! ${appFolderName}/${scriptName}:\n${error.message}\nनेटवर्क: ${hre.network.name}`;
    await sendTelegramMessage(telegramAlert);
    process.exit(1);
});
